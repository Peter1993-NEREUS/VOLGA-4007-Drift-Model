const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const EMBEDDED=true;
const TEST_USER={username:'demo',display_name:'NEREUS Test User',subscription_until:'30.09.2026'};
const state={token:localStorage.getItem('nereus_token')||'',user:null,reports:null,view:'brief',port:null,weatherLocation:null};
const deviceId=(()=>{let id=localStorage.getItem('nereus_device_id');if(!id){id=(crypto.randomUUID?crypto.randomUUID():Date.now()+'-'+Math.random());localStorage.setItem('nereus_device_id',id)}return id})();
function headers(){return {'Content-Type':'application/json','Authorization':'Bearer '+state.token,'X-Device-ID':deviceId}}
async function api(path,opt={}){
  if(EMBEDDED){
    if(path==='/api/auth/login'){
      const b=JSON.parse(opt.body||'{}');
      if(b.username==='demo'&&b.password==='Nereus2026!')return {access_token:'embedded-test-token',user:TEST_USER};
      throw Object.assign(new Error('Invalid username or password'),{status:401,data:{detail:'Invalid username or password'}});
    }
    if(path==='/api/me'){
      if(state.token==='embedded-test-token')return TEST_USER;
      throw Object.assign(new Error('Invalid session'),{status:401,data:{detail:'Invalid session'}});
    }
    if(path==='/api/reports'){
      const r=await fetch('embedded_reports.json?ts='+Date.now());
      if(!r.ok)throw new Error('Embedded report unavailable');
      return await r.json();
    }
  }
  const r=await fetch(path,{...opt,headers:{...headers(),...(opt.headers||{})}});let data=null;try{data=await r.json()}catch{}if(!r.ok)throw Object.assign(new Error(typeof data?.detail==='string'?data.detail:'Request failed'),{status:r.status,data});return data
}
function esc(s=''){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
function fmtQty(v){return v?esc(v)+' MT':'—'}
function statusClass(s){s=(s||'').toUpperCase();if(s==='ALLOWED')return'good';if(s.includes('NOT ALLOWED'))return'bad';return'warn'}
function showLogin(msg=''){ $('#login').classList.remove('hidden');$('#app').classList.add('hidden');$('#loginError').textContent=msg }
function showApp(){ $('#login').classList.add('hidden');$('#app').classList.remove('hidden');$('#userLine').textContent=`${state.user.display_name||state.user.username} · доступ до ${state.user.subscription_until}` }
function cacheReports(r){localStorage.setItem('nereus_reports',JSON.stringify({at:Date.now(),data:r}));localStorage.setItem('nereus_last_validated',String(Date.now()))}
function cachedReports(){try{return JSON.parse(localStorage.getItem('nereus_reports')||'null')}catch{return null}}
function canOffline(){const t=Number(localStorage.getItem('nereus_last_validated')||0);return Date.now()-t<24*3600*1000}
async function login(e){e.preventDefault();$('#loginError').textContent='';try{const data=await api('/api/auth/login',{method:'POST',body:JSON.stringify({username:$('#username').value.trim(),password:$('#password').value,device_id:deviceId,device_name:navigator.userAgent.slice(0,90)})});state.token=data.access_token;state.user=data.user;localStorage.setItem('nereus_token',state.token);showApp();await loadReports()}catch(err){showLogin(err.status===401?'Неверный логин или пароль.':'Не удалось войти.')}}
async function restore(){if(!state.token)return showLogin();try{state.user=await api('/api/me');localStorage.setItem('nereus_last_validated',String(Date.now()));showApp();await loadReports()}catch(err){localStorage.removeItem('nereus_token');state.token='';showLogin('Войдите в приложение.')}}
async function loadReports(){try{const r=await api('/api/reports');state.reports=r;cacheReports(r);render();offline('TEST BUILD: данные встроены в APK как снимок OPERATION REPORTS от 31.08.2026. Автообновление Google Sheets подключим к production API.','test')}catch(err){const c=cachedReports();if(c&&canOffline()){state.reports=c.data;render();offline(`Показаны сохранённые данные от ${new Date(c.at).toLocaleString('ru-RU')}.`)}else offline('Не удалось загрузить отчёт.')}}
function offline(text,cls=''){const b=$('#offlineBanner');b.textContent=text;b.className='banner'+(cls?' '+cls:'');b.classList.toggle('hidden',!text)}
function render(){if(!state.reports)return;$('#sourceMeta').textContent=state.reports.source==='google-sheets'?'LIVE · Google Sheets':'APK TEST SNAPSHOT';renderBrief();renderWeather();switchView(state.view)}
function chips(items,active){return `<div class="chips">${items.map(x=>`<button class="chip ${x===active?'active':''}" data-chip="${esc(x)}">${esc(x)}</button>`).join('')}</div>`}
function renderBrief(){const d=state.reports.mobile_brief;const ports=d.ports||[];if(!state.port||!ports.some(p=>p.name===state.port))state.port=ports[0]?.name;const p=ports.find(x=>x.name===state.port);let html=chips(ports.map(x=>x.name),state.port);if(p){for(const g of p.groups){html+=`<div class="section-title">${esc(g.status)} <span class="count">${g.vessels.length}</span></div>`;if(!g.vessels.length){html+='<div class="empty">Нет судов</div>';continue}html+=`<div class="cards">${g.vessels.map(v=>`<article class="vessel-card"><div class="vessel-head"><div><div class="vessel-name">${esc(v.vessel)}</div><div class="terminal">${esc(v.terminal||'—')}</div></div></div><div class="cargo"><span>${esc(v.cargo||'—')}</span><small>${fmtQty(v.qty_mt)}</small></div><div class="times"><div class="time"><span>ETA / ARR</span><b>${esc(v.eta||'—')}</b></div><div class="time"><span>ETB</span><b>${esc(v.etb||'—')}</b></div><div class="time"><span>ETS</span><b>${esc(v.ets||'—')}</b></div></div></article>`).join('')}</div>`}}$('#viewBrief').innerHTML=html;$('#viewBrief').querySelectorAll('[data-chip]').forEach(b=>b.onclick=()=>{state.port=b.dataset.chip;renderBrief()});if(state.view==='brief')$('#reportMeta').textContent=`Mobile Brief · ${d.report_date||''}`}
function renderWeather(){const d=state.reports.weather_report,locs=(d.locations||[]).filter(x=>(x.days||[]).length);if(!state.weatherLocation||!locs.some(x=>x.name===state.weatherLocation))state.weatherLocation=locs[0]?.name;const loc=locs.find(x=>x.name===state.weatherLocation);let html=chips(locs.map(x=>x.name),state.weatherLocation);if(loc){html+=`<div class="section-title">7 DAY FORECAST ${loc.gale_warning?'<span class="gale">GALE WARNING MONITORED</span>':''}</div><div class="weather-grid">${loc.days.map(x=>`<article class="weather-card"><div class="weather-date">${esc(x.date)}</div><div class="wx-row"><div class="wx-cell"><small>AM WIND / GUSTS</small><b>${esc(x.am_wind_dir)} · ${esc(x.am_gusts)} m/s</b></div><div class="wx-cell"><small>PM WIND / GUSTS</small><b>${esc(x.pm_wind_dir)} · ${esc(x.pm_gusts)} m/s</b></div></div><div class="wx-row"><div class="wx-cell"><small>WAVES</small><b>${esc(x.wave)} m</b></div><div class="wx-cell"><small>PERIOD</small><b>AM / PM</b></div></div><div class="ops"><div class="op ${statusClass(x.am_operations)}">AM · ${esc(x.am_operations)}</div><div class="op ${statusClass(x.pm_operations)}">PM · ${esc(x.pm_operations)}</div></div></article>`).join('')}</div>`}$('#viewWeather').innerHTML=html;$('#viewWeather').querySelectorAll('[data-chip]').forEach(b=>b.onclick=()=>{state.weatherLocation=b.dataset.chip;renderWeather()});if(state.view==='weather')$('#reportMeta').textContent=`Weather Report · ${d.report_date||''}`}
function switchView(v){state.view=v;$('#viewBrief').classList.toggle('hidden',v!=='brief');$('#viewWeather').classList.toggle('hidden',v!=='weather');$$('.navbtn').forEach(b=>b.classList.toggle('active',b.dataset.view===v));if(state.reports){const d=v==='brief'?state.reports.mobile_brief:state.reports.weather_report;$('#reportMeta').textContent=`${v==='brief'?'Mobile Brief':'Weather Report'} · ${d.report_date||''}`}}
$('#loginForm').addEventListener('submit',login);$('#refresh').onclick=loadReports;$('#logout').onclick=()=>{localStorage.removeItem('nereus_token');state.token='';state.user=null;showLogin()};$$('.navbtn').forEach(b=>b.onclick=()=>switchView(b.dataset.view));document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'&&state.token)loadReports()});restore();
